#!/usr/bin/env python3
"""
prepare-media.py — get generated technique clips ready for the Gojū-ryū dictionary.

What it does, for every MP4 you drop into videos/ :

  1. Normalises it to 16:9 H.264, no audio, web-optimised (faststart).
  2. Stretches it to a target duration by holding the final position,
     so a 1.8s generation becomes a readable 3s teaching clip.
  3. Extracts the LAST frame to images/<slug>.jpg, so the card's still
     always matches the end position of its own animation.
  4. Optionally writes a GIF fallback for browsers that block video.

Requires ffmpeg on PATH.

Usage
  python prepare-media.py                    # normalise + stills, 3.0s target
  python prepare-media.py --seconds 4        # longer hold on the final position
  python prepare-media.py --gif              # also write gifs/
  python prepare-media.py --raw raw-clips    # read from a different source folder
"""
import argparse, json, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent
VIDEOS, IMAGES, GIFS = ROOT / "videos", ROOT / "images", ROOT / "gifs"


def have_ffmpeg():
    return shutil.which("ffmpeg") and shutil.which("ffprobe")


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr.strip().splitlines()[-1] if r.stderr else "ffmpeg failed")
    return r


def duration(path):
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=nw=1:nk=1", str(path)])
    return float(r.stdout.strip())


def normalise(src, dst, target):
    """16:9 H.264, no audio, faststart, padded to `target` by freezing the last frame."""
    d = duration(src)
    hold = max(0.0, target - d)
    vf = ("scale=1280:720:force_original_aspect_ratio=decrease,"
          "pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0xFBF8F1,fps=24")
    if hold > 0.05:
        vf += ",tpad=stop_mode=clone:stop_duration=%.2f" % hold
    run(["ffmpeg", "-y", "-i", str(src), "-vf", vf, "-an",
         "-c:v", "libx264", "-profile:v", "baseline", "-pix_fmt", "yuv420p",
         "-crf", "23", "-movflags", "+faststart", str(dst)])
    return d, hold


def last_frame(src, dst):
    d = duration(src)
    run(["ffmpeg", "-y", "-ss", "%.3f" % max(0.0, d - 0.12), "-i", str(src),
         "-frames:v", "1", "-q:v", "3", str(dst)])


def make_gif(src, dst, fps=14, width=720):
    vf = (f"fps={fps},scale={width}:-1:flags=lanczos,split[a][b];"
          "[a]palettegen=max_colors=160[p];[b][p]paletteuse=dither=bayer:bayer_scale=3")
    run(["ffmpeg", "-y", "-i", str(src), "-vf", vf, "-loop", "0", str(dst)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="videos", help="folder holding the generated clips")
    ap.add_argument("--seconds", type=float, default=3.0, help="target clip length (2-5 works well)")
    ap.add_argument("--gif", action="store_true", help="also write GIF fallbacks")
    ap.add_argument("--no-stills", action="store_true", help="don't derive images/ from clips")
    a = ap.parse_args()

    if not have_ffmpeg():
        sys.exit("ffmpeg and ffprobe must be installed and on your PATH.")

    raw = ROOT / a.raw
    if not raw.is_dir():
        sys.exit("No folder called '%s' next to this script." % a.raw)

    clips = sorted(p for p in raw.iterdir() if p.suffix.lower() in (".mp4", ".mov", ".webm", ".m4v"))
    if not clips:
        sys.exit("No video files found in %s/" % a.raw)

    for d in (VIDEOS, IMAGES, GIFS):
        d.mkdir(exist_ok=True)

    expected = set()
    man = ROOT / "techniques.json"
    if man.exists():
        expected = {t["id"] for t in json.load(open(man))}

    ok, bad = [], []
    tmp = ROOT / "_tmp_media"
    tmp.mkdir(exist_ok=True)
    for clip in clips:
        slug = clip.stem.lower()
        try:
            out = tmp / (slug + ".mp4")
            src, held = normalise(clip, out, a.seconds)
            shutil.move(str(out), str(VIDEOS / (slug + ".mp4")))
            note = "%.1fs source" % src + (" +%.1fs hold" % held if held > 0.05 else "")
            if not a.no_stills:
                last_frame(VIDEOS / (slug + ".mp4"), IMAGES / (slug + ".jpg"))
                note += ", still from final frame"
            if a.gif:
                make_gif(VIDEOS / (slug + ".mp4"), GIFS / (slug + ".gif"))
                kb = (GIFS / (slug + ".gif")).stat().st_size / 1024
                note += ", gif %.0fKB" % kb
            mb = (VIDEOS / (slug + ".mp4")).stat().st_size / 1024
            print("  ok   %-18s %s (mp4 %.0fKB)" % (slug, note, mb))
            ok.append(slug)
        except Exception as e:
            print("  FAIL %-18s %s" % (slug, e))
            bad.append(slug)
    shutil.rmtree(tmp, ignore_errors=True)

    print("\n%d processed, %d failed." % (len(ok), len(bad)))
    if expected:
        missing = sorted(expected - set(ok))
        unknown = sorted(set(ok) - expected)
        if missing:
            print("Still missing (%d): %s" % (len(missing), ", ".join(missing)))
        if unknown:
            print("Not in techniques.json, check the filename: %s" % ", ".join(unknown))
        if not missing and not unknown:
            print("All 34 techniques covered.")


if __name__ == "__main__":
    main()
