# Gōjū-ryū dictionary — hostable bundle

Unzip and host this whole folder. `index.html` is the app.

## What's here

    index.html          the app (102 terms, works offline once loaded)
    images/             technique stills — images/<slug>.jpg
    videos/             technique clips  — videos/<slug>.mp4
    gifs/               fallback loops   — gifs/<slug>.gif
    techniques.json     the 34 slugs, for reference
    prepare-media.py    normalises clips, derives stills, reports what's missing

Currently populated: `images/choku-zuki.jpg` (caption band cropped off).
The other 33 fall back to the video still or the drawing until you add them.

## How each card resolves its media

1. `images/<slug>.jpg` — the still shown on the card
2. press play → `videos/<slug>.mp4` — loops, tap to pause, ✕ to go back
3. no mp4 → `gifs/<slug>.gif`
4. no gif → the YouTube demonstration, where one exists
5. nothing → a note naming the file to add

Drop files in, reload. No code changes.

## Hosting

Netlify Drop (app.netlify.com/drop): drag the whole folder in.
GitHub Pages: push the folder, enable Pages.
Cloudflare Pages: same drag-and-drop.

## Adding clips

    python prepare-media.py --raw raw-clips --seconds 3

Reads every video in `raw-clips/`, pads it to 3 seconds by holding the final
position, writes `videos/<slug>.mp4`, extracts the last frame to
`images/<slug>.jpg`, then lists which of the 34 are still missing.
Add `--gif` only if you want GIF fallbacks.
